# KPI Definitions

This document describes the core measures used in the Retail Revenue & Profitability Analysis.

| KPI | Definition / Formula | Interpretation |
|---|---|---|
| Total Revenue | Sum of `Sales_Amount` | Total sales value represented in the transaction data |
| Total COGS | Sum of `Cost_Amount` | Total recorded cost associated with the sold items |
| Gross Profit | Total Revenue − Total COGS | Revenue remaining after recorded product cost |
| Gross Profit Margin | Gross Profit ÷ Total Revenue × 100 | Gross profit as a percentage of revenue |
| Units Sold | Sum of `Quantity` | Net quantity represented by transaction rows, subject to returns/negative quantities |
| Transaction Count | Count of valid transaction records or distinct `Transaction_ID`, as defined in the workbook | Number of transaction lines or transactions; state which measure is used |
| Average Selling Price | Total Revenue ÷ Units Sold | Average revenue per unit; interpret carefully if returns or zero quantities exist |

## Calculation Notes
- Use the same row filters for numerator and denominator when calculating ratios.
- Confirm whether negative quantities represent returns or data errors before interpreting units sold.
- Do not substitute order count for transaction count. One order may contain multiple transaction lines.
- If revenue or cost values are missing, document the treatment before calculating totals.
- Gross profit margin is not the same as markup. Margin uses revenue as its denominator.

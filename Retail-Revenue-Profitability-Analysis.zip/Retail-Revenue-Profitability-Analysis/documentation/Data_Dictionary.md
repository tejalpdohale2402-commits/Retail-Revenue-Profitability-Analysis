# Data Dictionary

Field-level descriptions from the supplied `Data_Dictionary.csv` source file.

| Table | Column | Description | Expected Data Type |
|---|---|---|---|
| Sales_Transactions | Transaction_ID | Unique transaction line identifier | Text |
| Sales_Transactions | Order_ID | Order identifier | Text |
| Sales_Transactions | Order_Date | Transaction date; malformed values included | Date |
| Sales_Transactions | Customer_ID | Customer identifier; some missing | Text |
| Sales_Transactions | Product_ID | Product identifier | Text |
| Sales_Transactions | Store_ID | Store identifier | Text |
| Sales_Transactions | Quantity | Units purchased; invalid values included | Integer |
| Sales_Transactions | Unit_Price | Selling price before discount | Decimal |
| Sales_Transactions | Discount_Percentage | Discount rate; invalid values included | Decimal |
| Sales_Transactions | Sales_Amount | Revenue after discount | Decimal |
| Sales_Transactions | Cost_Amount | Estimated cost of goods sold | Decimal |
| Sales_Transactions | Payment_Method | Payment channel; inconsistent values included | Text |
| Customers | Customer_ID | Customer identifier; duplicate master rows included | Text |
| Customers | Customer_Name | Customer name | Text |
| Customers | Gender | Customer gender | Text |
| Customers | Age | Customer age; some missing | Integer |
| Customers | City | Customer city; some missing | Text |
| Customers | State | Customer state | Text |
| Customers | Customer_Segment | Customer segment | Text |
| Customers | Join_Date | Customer join date | Date |
| Products | Product_ID | Product identifier | Text |
| Products | Product_Name | Product name | Text |
| Products | Category | Product category; formatting issues included | Text |
| Products | Sub_Category | Product subcategory | Text |
| Products | Brand | Product brand | Text |
| Products | Standard_Cost | Reference cost per unit | Decimal |
| Products | List_Price | Reference list price | Decimal |
| Stores | Store_ID | Store identifier | Text |
| Stores | Store_Name | Store name | Text |
| Stores | City | Store city | Text |
| Stores | State | Store state | Text |
| Stores | Region | Business region | Text |
| Stores | Store_Type | Store format | Text |
| Stores | Opening_Date | Store opening date | Date |
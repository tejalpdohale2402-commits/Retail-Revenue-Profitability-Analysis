# Retail Revenue & Profitability Analysis

## 1. Project Overview
This project analyzes retail sales transactions to understand revenue, cost, gross profit, profitability, and business performance across time, regions, countries, and sales channels.

**Primary tool:** Microsoft Excel  
**Supporting tools:** Power Query, Excel Tables, PivotTables, PivotCharts, slicers, and dashboard features  
**Project status:** Completed

## 2. Business Context
A retail business needs a clear view of sales and profitability to understand what is performing well and where management should investigate further. This analysis organizes transaction-level data and converts it into business-focused KPIs and interactive reporting.

## 3. Project Objectives
- Prepare and clean transaction data using Power Query.
- Validate data quality, including date errors, missing values, and duplicate records.
- Create useful date attributes such as year, month, and quarter.
- Calculate core sales and profitability KPIs.
- Analyze revenue and profitability over time and across business dimensions.
- Present findings in an interactive Excel dashboard.

## 4. Dataset Summary
The supplied project data contains five CSV files:

| File | Rows | Purpose |
|---|---:|---|
| Sales_Transactions.csv | 10,025 | Transaction-level sales and cost data |
| Customers.csv | 1,005 | Customer attributes |
| Products.csv | 250 | Product and pricing attributes |
| Stores.csv | 20 | Store and regional attributes |
| Data_Dictionary.csv | 34 | Field descriptions and expected data types |

The sales transaction table contains 12 columns. The raw transaction file has 10,025 rows. The cleaned project output was reported as 10,000 rows.

## 5. Data Model
The transaction table is the central fact-like table. It contains customer, product, and store identifiers that can be used to relate transactions to the corresponding lookup tables.

- `Sales_Transactions.Customer_ID` → `Customers.Customer_ID`
- `Sales_Transactions.Product_ID` → `Products.Product_ID`
- `Sales_Transactions.Store_ID` → `Stores.Store_ID`

Before using these relationships, validate key uniqueness and unmatched identifiers. Do not assume every transaction has a valid customer identifier.

## 6. Analysis Performed
- Data preparation and cleaning in Power Query.
- Date parsing and error review.
- Missing-value review.
- Duplicate validation, including transaction identifier checks.
- KPI development for revenue, cost, gross profit, and gross profit margin.
- PivotTable analysis of monthly revenue, regional performance, sales-channel contribution, and country performance.
- Interactive dashboard development.

## 7. Business KPIs
See [KPI_Definitions.md](KPI_Definitions.md) for formulas, interpretation, and calculation notes.

## 8. Deliverables
- Excel workbook containing data preparation, analysis, PivotTables, and dashboard.
- Raw source CSV files.
- Data dictionary.
- Project documentation and data-quality notes.
- Dashboard screenshots (add exported screenshots to the `screenshots/` folder before publishing).

## 9. Limitations and Assumptions
- Results depend on the supplied dataset and its definitions.
- Missing or invalid records should be treated according to documented cleaning rules.
- Gross profit is calculated as sales amount less cost amount, subject to the source data's definitions.
- The dataset's transaction grain should be confirmed before interpreting transaction counts as order counts.
- This is a portfolio analysis project, not an audited financial statement.

## 10. How to Use
1. Review the raw files in `data/raw/`.
2. Open the Excel workbook in `excel/`.
3. Review the Power Query cleaning steps and validation queries.
4. Explore PivotTables and dashboard filters.
5. Read the KPI and data-quality documentation before interpreting results.

## 11. Author
**Tejal Pratap Dohale**  
LinkedIn: https://linkedin.com/in/tejaldohale24  
GitHub: https://github.com/tejalpdohale2402-commits

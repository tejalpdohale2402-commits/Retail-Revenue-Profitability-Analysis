# Data Quality and Cleaning Notes

## 1. Source Files
The project source folder contains:
- `Sales_Transactions.csv`
- `Customers.csv`
- `Products.csv`
- `Stores.csv`
- `Data_Dictionary.csv`

## 2. Initial Sales Data Profile
Based on inspection of the supplied raw `Sales_Transactions.csv`:

| Check | Observed result |
|---|---:|
| Raw transaction rows | 10,025 |
| Columns | 12 |
| Distinct `Transaction_ID` values | 10,000 |
| Missing `Customer_ID` values | 100 |
| Missing `Discount_Percentage` values | 50 |
| Missing `Payment_Method` values | 80 |
| Duplicate full rows | 24 |
| Rows with negative `Quantity` | 5 |
| Rows with zero `Quantity` | 5 |
| Date values that failed a standard date parse during initial inspection | 8 |

These are raw-file observations, not a statement that every issue was deleted. Review the workbook's Power Query steps to understand the exact treatment applied.

## 3. Recommended Validation Controls
- Preserve an unchanged copy of every raw CSV.
- Check row counts before and after each transformation.
- Profile missing values by column.
- Validate date values before changing their data type.
- Check duplicate transaction identifiers and compare all source columns before removing records.
- Check negative and zero quantities to determine whether they represent returns, adjustments, or errors.
- Validate customer, product, and store identifiers against their lookup tables.
- Reconcile totals before and after cleaning.

## 4. Cleaning Principles
- Do not automatically replace missing values with zero.
- Do not delete rows solely because a key field is missing without assessing analytical impact.
- Keep a record of excluded or corrected rows and the reason for each action.
- Use a separate cleaned output rather than overwriting raw data.
- Re-run validation checks after cleaning.

## 5. Cleaned Dataset
The project work reported a cleaned transaction output of **10,000 rows**. Confirm the final workbook's loaded row count and query steps before treating this as the definitive cleaned count in any published results.

# Business Requirements

## Stakeholders
Retail management, sales operations, regional managers, and business analysts.

## Business Questions
1. What is total revenue for the reporting period?
2. What are total cost of goods sold and gross profit?
3. What is the overall gross profit margin?
4. How does revenue change by month, quarter, and year?
5. Which regions contribute the most revenue?
6. Which countries contribute the most revenue?
7. Which sales channels contribute the largest share of revenue?
8. Which products or product groups contribute most to revenue and profit?
9. Which locations show comparatively low profitability?
10. How do units sold and transaction volumes change over time?

## Reporting Requirements
- Provide an executive-level KPI summary.
- Include time-based revenue analysis.
- Include geographic and channel comparisons.
- Make the dashboard easy to filter and explore.
- Label units, date ranges, and calculation definitions clearly.
- Ensure that charts reconcile to the underlying PivotTables.

## Acceptance Criteria
- Raw and cleaned data are stored separately.
- Data-quality checks are documented.
- KPI formulas are defined.
- PivotTable results reconcile to the source data and documented filters.
- Dashboard visuals have clear titles and labels.
- Key findings are supported by actual workbook results.
